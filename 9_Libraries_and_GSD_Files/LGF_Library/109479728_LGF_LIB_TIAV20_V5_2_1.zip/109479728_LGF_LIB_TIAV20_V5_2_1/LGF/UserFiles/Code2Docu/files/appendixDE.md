## Service und Support

#### Industry Online Support

Sie haben Fragen oder brauchen Unterstützung?  
Über den Industry Online Support greifen Sie rund um die Uhr auf das gesamte Service und Support Know-how sowie auf unsere Dienstleistungen zu.

Der Industry Online Support ist die zentrale Adresse für Informationen zu unseren Produkten, Lösungen und Services.

Produktinformationen, Handbücher, Downloads, FAQs und Anwendungsbeispiele - alle Informationen sind mit wenigen Mausklicks erreichbar:

[support.industry.siemens.com](https://support.industry.siemens.com)

#### Technical Support

Der Technical Support von Siemens Industry unterstützt Sie schnell und kompetent bei allen technischen Anfragen mit einer Vielzahl maßgeschneiderter Angebote  
\- von der Basisunterstützung bis hin zu individuellen Supportverträgen.

Anfragen an den Technical Support stellen Sie per Web-Formular:

[siemens.com/supportrequest](https://www.siemens.com/supportrequest)

#### SITRAIN – Digital Industry Academy

Mit unseren weltweit verfügbaren Trainings für unsere Produkte und Lösungen unterstützen wir Sie praxisnah, mit innovativen Lernmethoden und mit einem kundenspezifisch abgestimmten Konzept.

Mehr zu den angebotenen Trainings und Kursen sowie deren Standorte und Termine erfahren Sie unter:

[siemens.de/sitrain](https://www.siemens.de/sitrain)

#### Serviceangebot

Unser Serviceangebot umfasst folgendes:
* Plant Data Services
* Ersatzteilservices
* Reparaturservices
* Vor-Ort und Instandhaltungsservices
* Retrofit- und Modernisierungsservices
* Serviceprogramme und Verträge

Ausführliche Informationen zu unserem Serviceangebot finden Sie im Servicekatalog:

[support.industry.siemens.com/cs/sc](https://support.industry.siemens.com/cs/sc)

#### Industry Online Support App

Mit der App "Siemens Industry Online Support" erhalten Sie auch unterwegs die optimale Unterstützung. Die App ist für iOS und Android verfügbar:

[support.industry.siemens.com/cs/ww/de/sc/2067](https://support.industry.siemens.com/cs/ww/de/sc/2067)

## Industry Mall
 
![Siemens Industry Mall](SiemensIndustryMall.png)
 
Die Siemens Industry Mall ist die Plattform, auf der das gesamte Produktportfolio von Siemens Industry zugänglich ist. Von der Auswahl der Produkte über die Bestellung und die Lieferverfolgung ermöglicht die Industry Mall die komplette Einkaufsabwicklung – direkt und unabhängig von Zeit und Ort:

[mall.industry.siemens.com](https://mall.industry.siemens.com)