## Service and support

#### SiePortal

The integrated platform for product selection, purchasing and support - and connection of Industry Mall and Online support. The SiePortal home page replaces the previous home pages of the Industry Mall and the Online Support Portal (SIOS) and combines them.

* Products & Services  
  In Products & Services, you can find all our offerings as previously available in Mall Catalog.
* Support  
  In Support, you can find all information helpful for resolving technical issues with our products.
* mySieportal  
  mySiePortal collects all your personal data and processes, from your account to current orders, service requests and more. You can only see the full range of functions here after you have logged in.

You can access SiePortal via this address: [sieportal.siemens.com](https://sieportal.siemens.com)

#### Technical Support

The Technical Support of Siemens Industry provides you fast and competent support regarding all technical queries with numerous tailor-made offers \- ranging from basic support to individual support contracts.

Please send queries to Technical Support via Web form:  
[support.industry.siemens.com/cs/my/src](https://support.industry.siemens.com/cs/my/src)

#### SITRAIN - Digital Industry Academy

We support you with our globally available training courses for industry with practical experience, innovative learning methods and a concept that's tailored to the customer's specific needs.  
For more information on our offered trainings and courses, as well as their locations and dates, refer to our web page:

[siemens.com/sitrain](https://www.siemens.com/sitrain)

#### Industry Online Support app

You will receive optimum support wherever you are with the "Siemens Industry Online Support" app. The app is available for iOS and Android:

![Industry Online Support App](../Images/SiemensIndustryApp.png)

------

## Industry Mall

![Siemens Industry Mall](../Images/SiemensIndustryMall.png)

The Siemens Industry Mall is the platform on which the entire Siemens Industry product portfolio is accessible. From the selection of products to the order and the delivery tracking, the Industry Mall enables the complete purchasing processing – directly and independently of time and location:  
[mall.industry.siemens.com](https://mall.industry.siemens.com)