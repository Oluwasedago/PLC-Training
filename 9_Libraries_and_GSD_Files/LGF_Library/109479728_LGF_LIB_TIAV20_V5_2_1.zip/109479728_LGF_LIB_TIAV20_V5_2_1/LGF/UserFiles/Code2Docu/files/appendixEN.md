## Service and support

#### Industry Online Support

Do you have any questions or need assistance?  
Siemens Industry Online Support offers round the clock access to our entire service and support know-how and portfolio.

The Industry Online Support is the central address for information about our products, solutions and services.

Product information, manuals, downloads, FAQs, application examples and videos - all information is accessible with just a few mouse clicks:

[support.industry.siemens.com](https://support.industry.siemens.com)

#### Technical Support

The Technical Support of Siemens Industry provides you fast and competent support regarding all technical queries with numerous tailor-made offers  
\- ranging from basic support to individual support contracts. Please send queries to Technical Support via Web form:  

[siemens.com/supportrequest](https://www.siemens.com/supportrequest)

#### SITRAIN - Digital Industry Academy

We support you with our globally available training courses for industry with practical experience, innovative learning methods and a concept that's tailored to the customer's specific needs.

For more information on our offered trainings and courses, as well as their locations and dates, refer to our web page:

[siemens.de/sitrain](https://www.siemens.de/sitrain)

#### Service offer

Our range of services includes the following:
* Plant data services
* Spare parts services
* Repair services
* On-site and maintenance services
* Retrofitting and modernization services
* Service programs and contract's

You can find detailed information on our range of services in the service catalog web page:

[support.industry.siemens.com/cs/sc](https://support.industry.siemens.com/cs/sc)  

#### Industry Online Support app

You will receive optimum support wherever you are with the "Siemens Industry Online Support" app. The app is available for iOS and Android:

[support.industry.siemens.com/cs/ww/de/sc/2067](https://support.industry.siemens.com/cs/ww/de/sc/2067)

## Industry Mall
 
![Siemens Industry Mall](SiemensIndustryMall.png)

The Siemens Industry Mall is the platform on which the entire Siemens Industry product portfolio is accessible. From the selection of products to the order and the delivery tracking, the Industry Mall enables the complete purchasing processing – directly and independently of time and location:  
[mall.industry.siemens.com](https://mall.industry.siemens.com)