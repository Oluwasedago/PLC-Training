 
 hljs.registerLanguage('scl', window.hljsDefineSCL);
 hljs.highlightAll();
 