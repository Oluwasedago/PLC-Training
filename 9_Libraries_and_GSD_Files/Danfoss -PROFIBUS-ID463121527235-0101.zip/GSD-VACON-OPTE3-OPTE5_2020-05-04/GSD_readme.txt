OPTE3 / OPTE5 PROFIBUS DP GSD file version info.

GSD_for_V009_firmware\Vac30CCF.gsd
----------------------------------

OPTE3 / OPTE5 PROFIBUS DP option board firmware requirement: V009 or newer.

Recommended GSD file for OPTE3 / OPTE5 PROFIBUS DP option board which contains firmware V009 or newer.

In this GSD file Slot 1 is locked for Safety communication and Slot 2 is locked for normal AC drive communication. This prevents configuration error when user tries configure Safety on Slot 2. 

Please note that slot locking causes problems with some PLC configuration tools like Siemens STEP 7 when using PPO types. In this case please use GSD_for_V009_firmware_STEP_7_PPO\Vac30CCF.gsd.

GSD_for_V009_firmware_STEP_7_PPO\Vac30CCF.gsd
---------------------------------------------

OPTE3 / OPTE5 PROFIBUS DP option board firmware requirement: V009 or newer.

Please use this GSD file if slot locking causes problems with PLC configuration tool. This problem is possible at least with Siemens STEP 7 when using PPO types.

GSD_for_V009_firmware_DP-V0\Vac30CCF.gsd
----------------------------------------

OPTE3 / OPTE5 PROFIBUS DP option board firmware requirement: V009 or newer.

It is recommended to use this GSD version in case where PROFIBUS is wanted to force into DP-V0 mode. This GSD version does not mention DP-V1 support. 

Pleese note that it is not possible to use PROFIsafe with a this GSD version.

GSD_for_V005_firmware_or_earlier\Vac30CCF.gsd
---------------------------------------------

OPTE3 / OPTE5 PROFIBUS DP option board firmware requirement: V005 or earlier.

Recommended GSD file for OPTE3 / OPTE5 PROFIBUS DP option board which contains firmware V005 or earlier.
